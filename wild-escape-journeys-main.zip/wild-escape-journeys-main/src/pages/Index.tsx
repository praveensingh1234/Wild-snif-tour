import { useEffect, useState } from "react";
import HeroSection from "@/components/HeroSection";
import DestinationsSection from "@/components/DestinationsSection";
import AdventureTypesSection from "@/components/AdventureTypesSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import SustainabilitySection from "@/components/SustainabilitySection";
import PlanTripSection from "@/components/PlanTripSection";
import FooterSection from "@/components/FooterSection";

const Index = () => {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  if (!isLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-mountain">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="font-montserrat text-primary font-medium">Loading your adventure...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <HeroSection />
      <DestinationsSection />
      <AdventureTypesSection />
      <TestimonialsSection />
      <SustainabilitySection />
      <PlanTripSection />
      <FooterSection />
    </div>
  );
};

export default Index;