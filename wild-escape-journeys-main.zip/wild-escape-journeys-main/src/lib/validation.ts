import { z } from "zod";

// Email validation schema
export const emailSchema = z
  .string()
  .min(1, "Email is required")
  .email("Please enter a valid email address")
  .max(100, "Email must be less than 100 characters");

// Newsletter signup schema
export const newsletterSchema = z.object({
  email: emailSchema,
});

// Trip planning form schema
export const tripPlanningSchema = z.object({
  destination: z
    .string()
    .min(1, "Please select a destination")
    .max(50, "Destination name too long"),
  adventureType: z
    .string()
    .min(1, "Please select an adventure type")
    .max(50, "Adventure type name too long"),
  startDate: z
    .string()
    .min(1, "Please select a start date"),
  endDate: z
    .string()
    .min(1, "Please select an end date"),
  budget: z
    .string()
    .min(1, "Please select a budget range"),
  groupSize: z
    .string()
    .min(1, "Please enter group size")
    .max(20, "Group size description too long"),
  specialRequests: z
    .string()
    .max(500, "Special requests must be less than 500 characters")
    .optional(),
});

// Contact form schema
export const contactSchema = z.object({
  name: z
    .string()
    .min(1, "Name is required")
    .max(50, "Name must be less than 50 characters")
    .regex(/^[a-zA-Z\s]+$/, "Name can only contain letters and spaces"),
  email: emailSchema,
  message: z
    .string()
    .min(1, "Message is required")
    .max(1000, "Message must be less than 1000 characters"),
});

export type NewsletterFormData = z.infer<typeof newsletterSchema>;
export type TripPlanningFormData = z.infer<typeof tripPlanningSchema>;
export type ContactFormData = z.infer<typeof contactSchema>;