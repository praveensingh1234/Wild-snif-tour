import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mountain, Waves, TreePine, Camera, Users, Compass } from "lucide-react";
import { useState, useEffect } from "react";
import raftingImage from "@/assets/rafting-adventure.jpg";
import campingImage from "@/assets/camping-forest.jpg";
import safariImage from "@/assets/wildlife-safari.jpg";

interface AdventureType {
  id: number;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  image: string;
  features: string[];
  duration: string;
  difficulty: string;
}

const adventureTypes: AdventureType[] = [
  {
    id: 1,
    title: "Mountain Trekking",
    description: "Challenge yourself with guided treks through pristine mountain trails, experiencing breathtaking vistas and diverse ecosystems.",
    icon: Mountain,
    image: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=800&h=600&fit=crop",
    features: ["Professional Guides", "Safety Equipment", "Base Camp Support", "Photography Spots"],
    duration: "3-14 days",
    difficulty: "Moderate to Expert"
  },
  {
    id: 2,
    title: "Water Adventures",
    description: "Navigate thrilling rapids, peaceful rivers, and pristine lakes with our water-based adventure experiences.",
    icon: Waves,
    image: raftingImage,
    features: ["Professional Instructors", "All Equipment Included", "Safety Training", "Scenic Routes"],
    duration: "Half day to 5 days",
    difficulty: "Beginner to Advanced"
  },
  {
    id: 3,
    title: "Forest Camping",
    description: "Immerse yourself in nature with eco-friendly camping experiences in the world's most beautiful forests.",
    icon: TreePine,
    image: campingImage,
    features: ["Eco-Friendly Camps", "Wildlife Viewing", "Stargazing", "Nature Walks"],
    duration: "2-7 days",
    difficulty: "Beginner to Intermediate"
  },
  {
    id: 4,
    title: "Wildlife Safari",
    description: "Witness incredible wildlife in their natural habitats while supporting conservation efforts and local communities.",
    icon: Camera,
    image: safariImage,
    features: ["Expert Naturalists", "Conservation Focus", "Cultural Experiences", "Photography Guidance"],
    duration: "3-10 days",
    difficulty: "Easy to Moderate"
  },
  {
    id: 5,
    title: "Cultural Immersion",
    description: "Connect with indigenous communities and learn traditional ways of living in harmony with nature.",
    icon: Users,
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop",
    features: ["Local Guides", "Traditional Activities", "Community Support", "Authentic Experiences"],
    duration: "2-8 days",
    difficulty: "Easy to Moderate"
  },
  {
    id: 6,
    title: "Exploration Expeditions",
    description: "Join scientific expeditions to remote locations, contributing to research while experiencing untouched wilderness.",
    icon: Compass,
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop",
    features: ["Scientific Research", "Remote Locations", "Expert Leadership", "Unique Access"],
    duration: "5-21 days",
    difficulty: "Intermediate to Expert"
  }
];

const AdventureTypesSection = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlay, setIsAutoPlay] = useState(true);

  useEffect(() => {
    if (isAutoPlay) {
      const interval = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % adventureTypes.length);
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [isAutoPlay]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % adventureTypes.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + adventureTypes.length) % adventureTypes.length);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  return (
    <section className="py-20 bg-gradient-to-b from-background to-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-6">
            Adventure Types
          </h2>
          <p className="font-open-sans text-lg text-muted-foreground max-w-3xl mx-auto">
            Choose your perfect adventure from our carefully curated experiences, 
            each designed to connect you with nature while ensuring your safety and comfort.
          </p>
        </div>

        {/* Main Carousel */}
        <div 
          className="relative max-w-6xl mx-auto"
          onMouseEnter={() => setIsAutoPlay(false)}
          onMouseLeave={() => setIsAutoPlay(true)}
        >
          <div className="overflow-hidden rounded-2xl shadow-nature">
            <div 
              className="flex transition-transform duration-700 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {adventureTypes.map((adventure) => (
                <div key={adventure.id} className="w-full flex-shrink-0">
                  <Card className="bg-card/80 backdrop-blur-sm border-0 shadow-none">
                    <div className="grid md:grid-cols-2 gap-0 min-h-[500px]">
                      {/* Image Side */}
                      <div className="relative overflow-hidden">
                        <img 
                          src={adventure.image} 
                          alt={adventure.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent" />
                        
                        {/* Floating Icon */}
                        <div className="absolute top-6 left-6 bg-primary/90 backdrop-blur-sm rounded-full p-4 animate-float">
                          <adventure.icon className="w-8 h-8 text-primary-foreground" />
                        </div>
                        
                        {/* Difficulty Badge */}
                        <div className="absolute bottom-6 left-6 bg-highlight/90 backdrop-blur-sm text-highlight-foreground rounded-lg px-4 py-2">
                          <span className="font-montserrat font-medium text-sm">{adventure.difficulty}</span>
                        </div>
                      </div>
                      
                      {/* Content Side */}
                      <CardContent className="p-8 flex flex-col justify-center">
                        <div className="mb-6">
                          <h3 className="font-playfair text-3xl font-bold text-foreground mb-4">
                            {adventure.title}
                          </h3>
                          <p className="font-open-sans text-muted-foreground text-lg leading-relaxed mb-6">
                            {adventure.description}
                          </p>
                          
                          <div className="flex items-center gap-4 mb-6 text-sm text-muted-foreground">
                            <span className="font-montserrat">
                              <strong>Duration:</strong> {adventure.duration}
                            </span>
                          </div>
                        </div>
                        
                        {/* Features Grid */}
                        <div className="grid grid-cols-2 gap-3 mb-8">
                          {adventure.features.map((feature, index) => (
                            <div key={index} className="flex items-center gap-2">
                              <div className="w-2 h-2 bg-primary rounded-full" />
                              <span className="font-open-sans text-sm text-foreground">{feature}</span>
                            </div>
                          ))}
                        </div>
                        
                        <div className="flex gap-4">
                          <Button variant="adventure" className="flex-1">
                            Learn More
                          </Button>
                          <Button variant="nature" className="flex-1">
                            Book Now
                          </Button>
                        </div>
                      </CardContent>
                    </div>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Arrows */}
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white shadow-card backdrop-blur-sm"
            onClick={prevSlide}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </Button>
          
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white shadow-card backdrop-blur-sm"
            onClick={nextSlide}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Button>
        </div>

        {/* Dots Indicator */}
        <div className="flex justify-center gap-3 mt-8">
          {adventureTypes.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentSlide 
                  ? 'bg-primary shadow-glow' 
                  : 'bg-muted-foreground/30 hover:bg-muted-foreground/50'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default AdventureTypesSection;