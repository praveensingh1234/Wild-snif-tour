import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Mountain, 
  Mail, 
  Phone, 
  MapPin, 
  Facebook, 
  Twitter, 
  Instagram, 
  Youtube,
  Leaf,
  Heart
} from "lucide-react";
import { newsletterSchema } from "@/lib/validation";
import { sanitizeInput, checkRateLimit } from "@/lib/security";
import { toast } from "sonner";
import SecurityErrorBoundary from "@/components/SecurityErrorBoundary";

const FooterSection = () => {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Rate limiting check
    if (!checkRateLimit('newsletter_signup', 3, 300000)) { // 3 attempts per 5 minutes
      toast.error("Too many attempts. Please try again in a few minutes.");
      return;
    }

    setIsSubmitting(true);

    try {
      // Sanitize input
      const sanitizedEmail = sanitizeInput(email);
      
      // Validate with Zod
      const validatedData = newsletterSchema.parse({ email: sanitizedEmail });
      
      // Simulate API call (replace with actual backend call)
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast.success("Successfully subscribed to our newsletter!");
      setEmail("");
    } catch (error) {
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error("Please enter a valid email address");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <SecurityErrorBoundary>
    <footer className="relative bg-gradient-to-b from-primary/90 to-primary text-primary-foreground overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-background/20 to-transparent" />
        <div className="absolute -top-10 -left-10 w-40 h-40 bg-primary-glow/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-20 -right-20 w-60 h-60 bg-highlight/10 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        {/* Main Footer Content */}
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8 mb-12">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <Mountain className="w-8 h-8 text-highlight" />
              <div>
                <h3 className="font-playfair text-2xl font-bold">
                  Wild<span className="text-highlight">Escape</span>
                </h3>
                <p className="font-montserrat text-sm text-primary-foreground/80">
                  Adventures
                </p>
              </div>
            </div>
            
            <p className="font-open-sans text-primary-foreground/90 leading-relaxed mb-6">
              Nature Awaits. Dare to Explore. Join us in sustainable adventure travel 
              that connects you with the world's most beautiful places while protecting them for future generations.
            </p>

            {/* Certifications */}
            <div className="flex items-center gap-2 text-sm text-primary-foreground/80">
              <Leaf className="w-4 h-4 text-green-400" />
              <span>Carbon Neutral Certified</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-primary-foreground/80 mt-2">
              <Heart className="w-4 h-4 text-red-400" />
              <span>Responsible Tourism Partner</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-montserrat font-semibold text-lg mb-6">Destinations</h4>
            <ul className="space-y-3 font-open-sans">
              {[
                "Himalayan Peaks",
                "Amazon Rainforest", 
                "African Safari",
                "Norwegian Fjords",
                "Patagonian Wilderness",
                "View All Destinations"
              ].map((link, index) => (
                <li key={index}>
                  <a href="#" className="text-primary-foreground/80 hover:text-highlight transition-colors hover:underline">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Adventures */}
          <div>
            <h4 className="font-montserrat font-semibold text-lg mb-6">Adventures</h4>
            <ul className="space-y-3 font-open-sans">
              {[
                "Mountain Trekking",
                "Water Adventures",
                "Forest Camping",
                "Wildlife Safari",
                "Cultural Immersion",
                "Exploration Expeditions"
              ].map((link, index) => (
                <li key={index}>
                  <a href="#" className="text-primary-foreground/80 hover:text-highlight transition-colors hover:underline">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact & Newsletter */}
          <div>
            <h4 className="font-montserrat font-semibold text-lg mb-6">Stay Connected</h4>
            
            {/* Contact Info */}
            <div className="space-y-3 mb-6 font-open-sans">
              <div className="flex items-center gap-3 text-primary-foreground/80">
                <Phone className="w-4 h-4" />
                <span>+1 (555) 123-WILD</span>
              </div>
              <div className="flex items-center gap-3 text-primary-foreground/80">
                <Mail className="w-4 h-4" />
                <span>hello@wildescape.com</span>
              </div>
              <div className="flex items-center gap-3 text-primary-foreground/80">
                <MapPin className="w-4 h-4" />
                <span>Adventure HQ, Nature Valley</span>
              </div>
            </div>

            {/* Newsletter */}
            <div className="mb-6">
              <p className="font-open-sans text-sm text-primary-foreground/90 mb-3">
                Get adventure tips & exclusive deals
              </p>
              <form onSubmit={handleNewsletterSubmit} className="flex gap-2">
                <Input 
                  type="email" 
                  placeholder="Your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  maxLength={100}
                  required
                  disabled={isSubmitting}
                  className="bg-white/10 border-white/20 text-primary-foreground placeholder:text-primary-foreground/60 backdrop-blur-sm"
                />
                <Button 
                  type="submit"
                  variant="adventure" 
                  size="sm"
                  disabled={isSubmitting}
                  className="bg-highlight hover:bg-highlight/90 disabled:opacity-50"
                >
                  {isSubmitting ? "..." : "Subscribe"}
                </Button>
              </form>
            </div>

            {/* Social Links */}
            <div className="flex gap-4">
              {[
                { icon: Facebook, href: "#" },
                { icon: Instagram, href: "#" },
                { icon: Twitter, href: "#" },
                { icon: Youtube, href: "#" }
              ].map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-all duration-300 hover:scale-110 backdrop-blur-sm"
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="font-open-sans text-sm text-primary-foreground/80">
              © 2024 WildEscape Adventures. All rights reserved. Made with ❤️ for nature lovers.
            </div>
            
            <div className="flex gap-6 font-open-sans text-sm">
              {[
                "Privacy Policy",
                "Terms & Conditions", 
                "Sustainability Report",
                "Travel Insurance"
              ].map((link, index) => (
                <a 
                  key={index}
                  href="#" 
                  className="text-primary-foreground/80 hover:text-highlight transition-colors hover:underline"
                >
                  {link}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
    </SecurityErrorBoundary>
  );
};

export default FooterSection;