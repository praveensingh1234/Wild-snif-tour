import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Leaf, Heart, Users, Recycle, TreePine, Award } from "lucide-react";
import { useState } from "react";

interface SustainabilityMetric {
  icon: React.ComponentType<any>;
  value: string;
  label: string;
  description: string;
}

interface EcoPractice {
  id: number;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  impact: string;
  color: string;
}

const metrics: SustainabilityMetric[] = [
  {
    icon: TreePine,
    value: "25,000+",
    label: "Trees Planted",
    description: "Through our reforestation partnerships"
  },
  {
    icon: Users,
    value: "150+",
    label: "Local Communities",
    description: "Supported through ethical tourism"
  },
  {
    icon: Recycle,
    value: "100%",
    label: "Carbon Neutral",
    description: "All trips offset through verified programs"
  },
  {
    icon: Award,
    value: "95%",
    label: "Guest Satisfaction",
    description: "Based on post-trip sustainability surveys"
  }
];

const ecoPractices: EcoPractice[] = [
  {
    id: 1,
    title: "Zero Waste Philosophy",
    description: "We minimize waste through reusable equipment, biodegradable supplies, and comprehensive recycling programs on all adventures.",
    icon: Recycle,
    impact: "80% waste reduction",
    color: "bg-green-500"
  },
  {
    id: 2,
    title: "Local Community Support",
    description: "We partner with indigenous and local communities, ensuring tourism benefits reach the people who protect these natural spaces.",
    icon: Users,
    impact: "150+ families supported",
    color: "bg-blue-500"
  },
  {
    id: 3,
    title: "Wildlife Conservation",
    description: "A portion of every trip fee goes directly to wildlife conservation projects and habitat protection initiatives.",
    icon: Heart,
    impact: "$2M+ donated to conservation",
    color: "bg-red-500"
  },
  {
    id: 4,
    title: "Carbon Neutral Travel",
    description: "All transportation emissions are offset through verified carbon reduction projects including renewable energy and reforestation.",
    icon: Leaf,
    impact: "100% carbon neutral since 2019",
    color: "bg-green-600"
  },
  {
    id: 5,
    title: "Ecosystem Restoration",
    description: "We actively participate in habitat restoration projects, from coral reef rehabilitation to forest replanting initiatives.",
    icon: TreePine,
    impact: "500 acres restored",
    color: "bg-emerald-500"
  },
  {
    id: 6,
    title: "Education & Awareness",
    description: "Every adventure includes environmental education, helping travelers become conservation ambassadors in their home communities.",
    icon: Award,
    impact: "10,000+ ambassadors trained",
    color: "bg-orange-500"
  }
];

const SustainabilitySection = () => {
  const [selectedPractice, setSelectedPractice] = useState<number | null>(null);

  return (
    <section className="py-20 bg-gradient-to-b from-background to-primary/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-6">
            Adventure with Purpose
          </h2>
          <p className="font-open-sans text-lg text-muted-foreground max-w-3xl mx-auto">
            Our commitment to sustainable tourism goes beyond just exploring nature – 
            we actively work to protect and preserve the environments we visit for future generations.
          </p>
        </div>

        {/* Impact Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {metrics.map((metric, index) => (
            <Card 
              key={index}
              className="text-center group hover:shadow-nature transition-all duration-300 bg-card/80 backdrop-blur-sm border-primary/10 animate-scale-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6">
                <div className="flex justify-center mb-4">
                  <div className="p-4 bg-primary/10 rounded-full group-hover:bg-primary/20 transition-colors">
                    <metric.icon className="w-8 h-8 text-primary" />
                  </div>
                </div>
                <div className="font-montserrat text-3xl font-bold text-foreground mb-2">
                  {metric.value}
                </div>
                <div className="font-montserrat font-semibold text-primary mb-2">
                  {metric.label}
                </div>
                <div className="font-open-sans text-sm text-muted-foreground">
                  {metric.description}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Eco Practices */}
        <div className="mb-16">
          <h3 className="font-playfair text-3xl font-bold text-center text-foreground mb-12">
            Our Sustainability Practices
          </h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {ecoPractices.map((practice, index) => (
              <Card 
                key={practice.id}
                className={`group cursor-pointer transition-all duration-500 hover:shadow-nature hover:-translate-y-2 bg-card/80 backdrop-blur-sm border-primary/10 animate-fade-in-up ${
                  selectedPractice === practice.id ? 'ring-2 ring-primary/30 shadow-glow' : ''
                }`}
                style={{ animationDelay: `${index * 150}ms` }}
                onClick={() => setSelectedPractice(selectedPractice === practice.id ? null : practice.id)}
              >
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-full ${practice.color} bg-opacity-10 group-hover:bg-opacity-20 transition-all duration-300`}>
                      <practice.icon className={`w-6 h-6 text-${practice.color.replace('bg-', '').replace('-500', '').replace('-600', '')}-600`} />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="font-montserrat text-lg font-semibold group-hover:text-primary transition-colors">
                        {practice.title}
                      </CardTitle>
                      <div className="text-sm text-primary font-medium mt-1">
                        {practice.impact}
                      </div>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="pt-0">
                  <p className={`font-open-sans text-sm text-muted-foreground leading-relaxed transition-all duration-300 ${
                    selectedPractice === practice.id ? 'max-h-32' : 'max-h-20 overflow-hidden'
                  }`}>
                    {practice.description}
                  </p>
                  
                  {selectedPractice !== practice.id && (
                    <div className="text-primary text-sm mt-2 group-hover:text-primary-glow transition-colors">
                      Click to learn more →
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-gradient-forest rounded-2xl p-8 md:p-12 text-center shadow-nature">
          <h3 className="font-playfair text-3xl font-bold text-primary-foreground mb-6">
            Travel Wild. Stay Rooted.
          </h3>
          <p className="font-open-sans text-lg text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
            Join us in creating positive change through responsible adventure travel. 
            Together, we can explore the world while protecting it for future generations.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              variant="nature" 
              size="lg"
              className="bg-white/90 text-primary hover:bg-white shadow-card"
            >
              View Our Impact Report
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm"
            >
              Learn About Our Partners
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SustainabilitySection;