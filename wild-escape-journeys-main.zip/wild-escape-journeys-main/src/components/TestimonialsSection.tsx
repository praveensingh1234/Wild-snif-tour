import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote } from "lucide-react";
import { useState, useEffect } from "react";

interface Testimonial {
  id: number;
  name: string;
  location: string;
  adventure: string;
  rating: number;
  text: string;
  image: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Sarah Mitchell",
    location: "Vancouver, Canada",
    adventure: "Himalayan Trek",
    rating: 5,
    text: "The Himalayan trek with WildEscape was transformative. The guides were incredibly knowledgeable about local ecology and culture. Every step was carefully planned with sustainability in mind. I returned home with not just memories, but a deeper appreciation for our planet.",
    image: "https://images.unsplash.com/photo-1494790108755-2616b612b77c?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: 2,
    name: "Marcus Rodriguez",
    location: "São Paulo, Brazil",
    adventure: "Amazon Rainforest",
    rating: 5,
    text: "Witnessing the Amazon's biodiversity firsthand was incredible. WildEscape's commitment to working with indigenous communities made this experience authentic and respectful. The night sounds of the rainforest will stay with me forever.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: 3,
    name: "Emma Chen",
    location: "Singapore",
    adventure: "African Safari",
    rating: 5,
    text: "The African safari exceeded all expectations. Seeing elephants, lions, and zebras in their natural habitat was magical. The conservation stories shared by our guides highlighted the importance of protecting these magnificent creatures.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: 4,
    name: "James Thompson",
    location: "London, UK",
    adventure: "Norwegian Fjords",
    rating: 5,
    text: "The Norwegian fjords cruise was absolutely breathtaking. Crystal clear waters, towering waterfalls, and the Northern Lights made this a once-in-a-lifetime experience. WildEscape's eco-friendly approach made me feel good about traveling.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face"
  },
  {
    id: 5,
    name: "Isabella Martinez",
    location: "Madrid, Spain",
    adventure: "Patagonian Wilderness",
    rating: 5,
    text: "Patagonia's raw beauty is indescribable. Glacier hiking and kayaking among icebergs felt like exploring another planet. The small group size and expert guides made this adventure both safe and incredibly personal.",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face"
  }
];

const TestimonialsSection = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-5 h-5 ${
          i < rating 
            ? 'text-yellow-400 fill-current' 
            : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <section className="py-20 bg-gradient-to-b from-secondary/30 to-background relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-32 h-32 bg-primary/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-20 w-48 h-48 bg-accent/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-highlight/5 rounded-full blur-2xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-6">
            Stories from Adventurers
          </h2>
          <p className="font-open-sans text-lg text-muted-foreground max-w-3xl mx-auto">
            Hear from fellow nature lovers who have experienced the magic of sustainable adventure travel 
            with WildEscape Adventures.
          </p>
        </div>

        {/* Featured Testimonial */}
        <div className="max-w-4xl mx-auto mb-16">
          <Card className="bg-gradient-mountain border-primary/20 shadow-nature backdrop-blur-sm">
            <CardContent className="p-8 md:p-12 text-center">
              {/* Quote Icon */}
              <div className="flex justify-center mb-6">
                <Quote className="w-12 h-12 text-primary/30" />
              </div>
              
              {/* Rating */}
              <div className="flex justify-center gap-1 mb-6">
                {renderStars(testimonials[currentTestimonial].rating)}
              </div>
              
              {/* Testimonial Text */}
              <blockquote className="font-open-sans text-xl md:text-2xl text-foreground leading-relaxed mb-8 italic">
                "{testimonials[currentTestimonial].text}"
              </blockquote>
              
              {/* Author Info */}
              <div className="flex items-center justify-center gap-4">
                <img 
                  src={testimonials[currentTestimonial].image}
                  alt={testimonials[currentTestimonial].name}
                  className="w-16 h-16 rounded-full object-cover border-4 border-primary/20"
                />
                <div className="text-left">
                  <div className="font-montserrat font-semibold text-lg text-foreground">
                    {testimonials[currentTestimonial].name}
                  </div>
                  <div className="text-muted-foreground text-sm">
                    {testimonials[currentTestimonial].location}
                  </div>
                  <div className="text-primary text-sm font-medium">
                    {testimonials[currentTestimonial].adventure}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Testimonial Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card 
              key={testimonial.id}
              className={`group cursor-pointer transition-all duration-500 hover:shadow-nature hover:-translate-y-1 bg-card/60 backdrop-blur-sm border-primary/10 ${
                index === currentTestimonial ? 'ring-2 ring-primary/30 shadow-glow' : ''
              }`}
              onClick={() => setCurrentTestimonial(index)}
            >
              <CardContent className="p-6">
                {/* Rating */}
                <div className="flex gap-1 mb-4">
                  {renderStars(testimonial.rating)}
                </div>
                
                {/* Text Preview */}
                <p className="font-open-sans text-sm text-muted-foreground leading-relaxed mb-4 line-clamp-3">
                  "{testimonial.text.substring(0, 120)}..."
                </p>
                
                {/* Author */}
                <div className="flex items-center gap-3">
                  <img 
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-montserrat font-medium text-sm text-foreground">
                      {testimonial.name}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {testimonial.adventure}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Navigation Dots */}
        <div className="flex justify-center gap-2 mt-12">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentTestimonial(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentTestimonial 
                  ? 'bg-primary shadow-glow scale-125' 
                  : 'bg-muted-foreground/30 hover:bg-muted-foreground/50'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;