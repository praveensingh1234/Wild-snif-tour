import { Button } from "@/components/ui/button";
import { ArrowDown, Mountain, TreePine } from "lucide-react";
import heroImage from "@/assets/hero-mountain.jpg";

const HeroSection = () => {
  const scrollToNext = () => {
    const nextSection = document.getElementById('explore-destinations');
    nextSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Parallax Effect */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-black/60" />
      </div>
      
      {/* Floating Elements */}
      <div className="absolute top-20 left-10 animate-float">
        <TreePine className="w-8 h-8 text-white/30" />
      </div>
      <div className="absolute top-32 right-16 animate-float" style={{ animationDelay: '1s' }}>
        <Mountain className="w-6 h-6 text-white/40" />
      </div>
      
      {/* Main Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <div className="animate-fade-in-up">
          <h1 className="font-playfair text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Wild<span className="text-highlight">Escape</span>
            <br />
            <span className="text-3xl md:text-5xl font-montserrat font-light">Adventures</span>
          </h1>
          
          <p className="font-open-sans text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed">
            Nature Awaits. Dare to Explore.
          </p>
          
          <p className="font-open-sans text-lg text-white/80 mb-12 max-w-3xl mx-auto">
            Discover breathtaking landscapes, wildlife encounters, and sustainable adventures 
            that connect you with nature while preserving our planet's beauty.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Button 
              variant="hero" 
              size="xl"
              onClick={scrollToNext}
              className="group"
            >
              Start Your Adventure
              <ArrowDown className="w-5 h-5 group-hover:animate-bounce" />
            </Button>
            
            <Button 
              variant="nature" 
              size="xl"
              className="bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20"
            >
              View Gallery
            </Button>
          </div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ArrowDown className="w-6 h-6 text-white/70" />
      </div>
    </div>
  );
};

export default HeroSection;