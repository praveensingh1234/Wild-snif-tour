import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Star, Users } from "lucide-react";
import { useState } from "react";

interface Destination {
  id: number;
  name: string;
  location: string;
  description: string;
  rating: number;
  visitors: string;
  image: string;
  activities: string[];
}

const destinations: Destination[] = [
  {
    id: 1,
    name: "Himalayan Peaks",
    location: "Nepal & Tibet",
    description: "Experience the world's highest mountains with guided treks through ancient trails and breathtaking vistas.",
    rating: 4.9,
    visitors: "2.3k",
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop",
    activities: ["Trekking", "Mountaineering", "Photography"]
  },
  {
    id: 2,
    name: "Amazon Rainforest",
    location: "Brazil & Peru",
    description: "Immerse yourself in the world's largest tropical rainforest with wildlife spotting and canopy walks.",
    rating: 4.8,
    visitors: "1.8k",
    image: "https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=600&h=400&fit=crop",
    activities: ["Wildlife Safari", "River Cruise", "Birdwatching"]
  },
  {
    id: 3,
    name: "Patagonian Wilderness",
    location: "Chile & Argentina",
    description: "Explore dramatic landscapes of glaciers, mountains, and pristine lakes in South America's last frontier.",
    rating: 4.7,
    visitors: "1.2k",
    image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=600&h=400&fit=crop",
    activities: ["Glacier Hiking", "Kayaking", "Wildlife Viewing"]
  },
  {
    id: 4,
    name: "African Savanna",
    location: "Kenya & Tanzania",
    description: "Witness the Great Migration and discover Africa's incredible wildlife in their natural habitat.",
    rating: 4.9,
    visitors: "3.1k",
    image: "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=600&h=400&fit=crop",
    activities: ["Safari", "Cultural Tours", "Balloon Rides"]
  },
  {
    id: 5,
    name: "Norwegian Fjords",
    location: "Norway",
    description: "Cruise through majestic fjords surrounded by towering waterfalls and snow-capped mountains.",
    rating: 4.8,
    visitors: "2.7k",
    image: "https://images.unsplash.com/photo-1531572753322-ad063cecc140?w=600&h=400&fit=crop",
    activities: ["Fjord Cruising", "Northern Lights", "Fishing"]
  },
  {
    id: 6,
    name: "Costa Rican Cloud Forest",
    location: "Costa Rica",
    description: "Discover biodiversity hotspots with zip-lining through misty cloud forests and wildlife encounters.",
    rating: 4.6,
    visitors: "1.9k",
    image: "https://images.unsplash.com/photo-1518639192441-8fce0a31af15?w=600&h=400&fit=crop",
    activities: ["Zip-lining", "Wildlife Tours", "Canopy Walks"]
  }
];

const DestinationsSection = () => {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);

  return (
    <section id="explore-destinations" className="py-20 bg-gradient-mountain">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-6">
            Explore Epic Destinations
          </h2>
          <p className="font-open-sans text-lg text-muted-foreground max-w-3xl mx-auto">
            From towering mountain peaks to pristine rainforests, discover the world's most spectacular 
            natural wonders through sustainable and responsible travel experiences.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {destinations.map((destination, index) => (
            <Card 
              key={destination.id}
              className={`group cursor-pointer transition-all duration-500 hover:shadow-nature hover:-translate-y-2 animate-scale-in bg-card/80 backdrop-blur-sm border-primary/10 ${
                hoveredCard === destination.id ? 'shadow-glow' : ''
              }`}
              style={{ animationDelay: `${index * 100}ms` }}
              onMouseEnter={() => setHoveredCard(destination.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              <div className="relative overflow-hidden rounded-t-lg">
                <img 
                  src={destination.image} 
                  alt={destination.name}
                  className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {/* Floating Stats */}
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-2 transform translate-x-full group-hover:translate-x-0 transition-transform duration-300">
                  <div className="flex items-center gap-1 text-sm">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span className="font-semibold">{destination.rating}</span>
                  </div>
                </div>
                
                <div className="absolute bottom-4 left-4 bg-primary/90 backdrop-blur-sm text-primary-foreground rounded-lg p-2 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300 delay-100">
                  <div className="flex items-center gap-1 text-sm">
                    <Users className="w-4 h-4" />
                    <span>{destination.visitors} visitors</span>
                  </div>
                </div>
              </div>
              
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="font-montserrat text-xl font-semibold group-hover:text-primary transition-colors">
                      {destination.name}
                    </CardTitle>
                    <div className="flex items-center gap-1 text-muted-foreground mt-1">
                      <MapPin className="w-4 h-4" />
                      <span className="font-open-sans text-sm">{destination.location}</span>
                    </div>
                  </div>
                </div>
                
                <CardDescription className="font-open-sans text-sm leading-relaxed mt-3">
                  {destination.description}
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <div className="flex flex-wrap gap-2 mb-4">
                  {destination.activities.map((activity) => (
                    <span 
                      key={activity}
                      className="px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium"
                    >
                      {activity}
                    </span>
                  ))}
                </div>
                
                <Button 
                  variant="adventure" 
                  className="w-full group-hover:bg-gradient-forest"
                >
                  Explore Destination
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="hero" size="lg">
            View All Destinations
          </Button>
        </div>
      </div>
    </section>
  );
};

export default DestinationsSection;