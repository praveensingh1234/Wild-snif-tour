import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  MapPin, 
  Calendar, 
  Users, 
  DollarSign, 
  Mountain, 
  Camera, 
  Tent,
  Fish,
  Phone,
  Clock,
  CheckCircle2
} from 'lucide-react';
import { tripPlanningSchema, type TripPlanningFormData } from '@/lib/validation';
import { sanitizeInput, checkRateLimit } from '@/lib/security';
import { toast } from 'sonner';
import SecurityErrorBoundary from '@/components/SecurityErrorBoundary';

interface TripStep {
  id: number;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  isCompleted: boolean;
}

const PlanTripSection = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState<TripPlanningFormData>({
    destination: '',
    adventureType: '',
    startDate: '',
    endDate: '',
    budget: '',
    groupSize: '',
    specialRequests: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const steps: TripStep[] = [
    {
      id: 1,
      title: "Destination",
      description: "Where do you want to go?",
      icon: MapPin,
      isCompleted: currentStep > 1
    },
    {
      id: 2,
      title: "Adventure Type",
      description: "What calls to you?",
      icon: Mountain,
      isCompleted: currentStep > 2
    },
    {
      id: 3,
      title: "Trip Details",
      description: "Dates and duration",
      icon: Calendar,
      isCompleted: currentStep > 3
    },
    {
      id: 4,
      title: "Budget & Group",
      description: "Budget and special requests",
      icon: DollarSign,
      isCompleted: currentStep > 4
    }
  ];

  const handleInputChange = (field: string, value: string) => {
    // Sanitize input
    const sanitizedValue = sanitizeInput(value);
    
    setFormData(prev => ({
      ...prev,
      [field]: sanitizedValue
    }));
    
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: ''
      }));
    }
  };

  const validateCurrentStep = (): boolean => {
    const newErrors: Record<string, string> = {};
    
    switch (currentStep) {
      case 1:
        if (!formData.destination) newErrors.destination = "Please select a destination";
        break;
      case 2:
        if (!formData.adventureType) newErrors.adventureType = "Please select an adventure type";
        break;
      case 3:
        if (!formData.startDate) newErrors.startDate = "Please select a start date";
        if (!formData.endDate) newErrors.endDate = "Please select an end date";
        if (formData.startDate && formData.endDate && new Date(formData.startDate) >= new Date(formData.endDate)) {
          newErrors.endDate = "End date must be after start date";
        }
        break;
      case 4:
        if (!formData.budget) newErrors.budget = "Please select a budget range";
        if (!formData.groupSize) newErrors.groupSize = "Please enter group size";
        break;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const nextStep = () => {
    if (validateCurrentStep() && currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    // Rate limiting check
    if (!checkRateLimit('trip_planning', 2, 300000)) { // 2 attempts per 5 minutes
      toast.error("Too many submissions. Please try again in a few minutes.");
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Final validation with Zod
      const validatedData = tripPlanningSchema.parse(formData);
      
      // Simulate API submission (replace with actual backend call)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast.success("Trip request submitted successfully! We'll contact you within 24 hours.");
      
      // Reset form
      setFormData({
        destination: '',
        adventureType: '',
        startDate: '',
        endDate: '',
        budget: '',
        groupSize: '',
        specialRequests: ''
      });
      setCurrentStep(1);
      setErrors({});
      
    } catch (error) {
      if (error instanceof Error) {
        toast.error("Please check all required fields and try again.");
      } else {
        toast.error("An error occurred. Please try again.");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStepContent = (): JSX.Element | null => {
    switch (currentStep) {
      case 1:
        return (
          <div>
            <Select onValueChange={(value) => handleInputChange('destination', value)} value={formData.destination}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Choose your dream destination" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="himalayas">Himalayan Peaks, Nepal</SelectItem>
                <SelectItem value="amazon">Amazon Rainforest, Peru</SelectItem>
                <SelectItem value="safari">African Safari, Kenya</SelectItem>
                <SelectItem value="fjords">Norwegian Fjords</SelectItem>
                <SelectItem value="patagonia">Patagonian Wilderness</SelectItem>
                <SelectItem value="borneo">Borneo Jungle, Malaysia</SelectItem>
              </SelectContent>
            </Select>
            {errors.destination && <p className="text-sm text-destructive mt-1">{errors.destination}</p>}
          </div>
        );

      case 2:
        return (
          <div>
            <Select onValueChange={(value) => handleInputChange('adventureType', value)} value={formData.adventureType}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="What kind of adventure calls you?" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="trekking">Mountain Trekking</SelectItem>
                <SelectItem value="safari">Wildlife Safari</SelectItem>
                <SelectItem value="water">Water Adventures</SelectItem>
                <SelectItem value="camping">Forest Camping</SelectItem>
                <SelectItem value="cultural">Cultural Immersion</SelectItem>
                <SelectItem value="expedition">Exploration Expedition</SelectItem>
              </SelectContent>
            </Select>
            {errors.adventureType && <p className="text-sm text-destructive mt-1">{errors.adventureType}</p>}
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="startDate" className="text-base font-medium mb-2 block">Start Date</Label>
              <Input 
                type="date" 
                value={formData.startDate}
                onChange={(e) => handleInputChange('startDate', e.target.value)}
                className="w-full"
              />
              {errors.startDate && <p className="text-sm text-destructive mt-1">{errors.startDate}</p>}
            </div>
            <div>
              <Label htmlFor="endDate" className="text-base font-medium mb-2 block">End Date</Label>
              <Input 
                type="date" 
                value={formData.endDate}
                onChange={(e) => handleInputChange('endDate', e.target.value)}
                className="w-full"
              />
              {errors.endDate && <p className="text-sm text-destructive mt-1">{errors.endDate}</p>}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-4">
            <Select onValueChange={(value) => handleInputChange('budget', value)} value={formData.budget}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="What's your adventure budget?" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="budget">Budget Explorer ($500-$1,500)</SelectItem>
                <SelectItem value="standard">Standard Adventure ($1,500-$3,000)</SelectItem>
                <SelectItem value="premium">Premium Experience ($3,000-$5,000)</SelectItem>
                <SelectItem value="luxury">Luxury Expedition ($5,000+)</SelectItem>
              </SelectContent>
            </Select>
            {errors.budget && <p className="text-sm text-destructive mt-1">{errors.budget}</p>}
            
            <div className="mt-4">
              <Label htmlFor="groupSize" className="text-base font-medium mb-2 block">Group Size</Label>
              <Input 
                placeholder="e.g., 2 adults, 1 child" 
                value={formData.groupSize}
                maxLength={20}
                onChange={(e) => handleInputChange('groupSize', e.target.value)}
                className="w-full"
              />
              {errors.groupSize && <p className="text-sm text-destructive mt-1">{errors.groupSize}</p>}
            </div>

            <div className="mt-4">
              <Label htmlFor="specialRequests" className="text-base font-medium mb-2 block">
                Special Requests (Optional)
              </Label>
              <Textarea 
                placeholder="Tell us about any dietary restrictions, accessibility needs, special occasions, or specific experiences you're hoping for..."
                className="min-h-[120px] resize-none"
                value={formData.specialRequests}
                maxLength={500}
                onChange={(e) => handleInputChange('specialRequests', e.target.value)}
              />
              <p className="text-sm text-muted-foreground mt-1">
                {formData.specialRequests?.length || 0}/500 characters
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <SecurityErrorBoundary>
      <section className="py-20 bg-gradient-to-b from-background to-secondary/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-playfair text-4xl md:text-5xl font-bold text-foreground mb-6">
              Plan Your Perfect Adventure
            </h2>
            <p className="font-open-sans text-lg text-muted-foreground max-w-3xl mx-auto">
              Let us create a personalized adventure that matches your dreams and experience level.
            </p>
          </div>

          <div className="max-w-2xl mx-auto">
            {/* Progress Indicator */}
            <div className="mb-8">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-muted-foreground">
                  Step {currentStep} of {steps.length}
                </span>
                <span className="text-sm font-medium text-muted-foreground">
                  {Math.round((currentStep / steps.length) * 100)}% Complete
                </span>
              </div>
              <Progress value={(currentStep / steps.length) * 100} className="h-2" />
            </div>

            {/* Step Header */}
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
                {React.createElement(steps[currentStep - 1].icon, { 
                  className: "w-8 h-8 text-primary" 
                })}
              </div>
              <h3 className="font-playfair text-2xl font-bold text-foreground mb-2">
                {steps[currentStep - 1].title}
              </h3>
              <p className="font-open-sans text-muted-foreground">
                {steps[currentStep - 1].description}
              </p>
            </div>

            {/* Form Card */}
            <Card className="shadow-nature bg-card/80 backdrop-blur-sm border-primary/10">
              <CardContent className="p-8">
                {renderStepContent()}

                <div className="flex justify-between pt-6">
                  {currentStep > 1 && (
                    <Button 
                      variant="outline" 
                      onClick={prevStep}
                      disabled={isSubmitting}
                      className="flex items-center gap-2"
                    >
                      Previous Step
                    </Button>
                  )}
                  
                  <div className="ml-auto">
                    {currentStep < steps.length ? (
                      <Button 
                        onClick={nextStep}
                        disabled={isSubmitting}
                        className="bg-primary hover:bg-primary/90 flex items-center gap-2"
                      >
                        Next Step
                      </Button>
                    ) : (
                      <Button 
                        onClick={handleSubmit}
                        disabled={isSubmitting}
                        className="bg-highlight hover:bg-highlight/90 flex items-center gap-2 disabled:opacity-50"
                      >
                        {isSubmitting ? "Submitting..." : "Submit Request"}
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Contact Alternative */}
            <div className="text-center mt-12">
              <p className="font-open-sans text-muted-foreground mb-4">
                Prefer to speak with an adventure specialist?
              </p>
              <Button variant="nature" size="lg" className="bg-secondary hover:bg-secondary/90">
                <Phone className="w-4 h-4 mr-2" />
                Schedule a Call
              </Button>
            </div>
          </div>
        </div>
      </section>
    </SecurityErrorBoundary>
  );
};

export default PlanTripSection;